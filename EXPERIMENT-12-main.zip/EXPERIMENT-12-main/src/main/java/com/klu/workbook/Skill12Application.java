package com.klu.workbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Skill12Application {

	public static void main(String[] args) {
		SpringApplication.run(Skill12Application.class, args);
	}

}
